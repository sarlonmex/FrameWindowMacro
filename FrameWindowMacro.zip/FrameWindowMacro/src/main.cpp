#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>

#include <algorithm>
#include <climits>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <map>
#include <sstream>
#include <vector>

using namespace geode::prelude;

// ---------------------------------------------------------------------------
// Datenmodell
// ---------------------------------------------------------------------------
struct MacroInput {
	int frame;   // Physik-Schritt seit Levelstart
	bool down;   // true = gedrückt, false = losgelassen
	int button;  // 1 = Jump, 2 = Links, 3 = Rechts
	bool p1;     // Spieler 1 / 2
};

namespace Macro {
	inline bool recording = false;
	inline bool armed = false;      // startet beim nächsten Level-Restart
	inline int frame = 0;
	inline std::vector<MacroInput> inputs;
	inline std::string lastReport;
	inline std::string lastSummary;
	inline std::string lastPath;
}

// ---------------------------------------------------------------------------
// Scan / Frame-Window-Analyse
// ---------------------------------------------------------------------------
static void analyzeMacro() {
	auto& in = Macro::inputs;
	double tps = static_cast<double>(Mod::get()->getSettingValue<int64_t>("tps"));
	int tight = static_cast<int>(Mod::get()->getSettingValue<int64_t>("tight-frames"));
	double msPerFrame = 1000.0 / tps;
	int gridStep = std::max(1, static_cast<int>(tps / 60.0 + 0.5)); // 240 TPS -> 4

	std::ostringstream o;
	o << std::fixed << std::setprecision(2);

	if (in.empty()) {
		Macro::lastReport = "Keine Inputs aufgenommen.";
		Macro::lastSummary = Macro::lastReport;
		return;
	}

	int total = Macro::frame;
	size_t presses = std::count_if(in.begin(), in.end(), [](auto& i) { return i.down; });

	o << "=== FRAME WINDOW REPORT ===\n";
	o << "TPS: " << tps << "  |  1 Frame = " << msPerFrame << " ms\n";
	o << "Frames gesamt: " << total << " (" << total / tps << " s)\n";
	o << "Inputs: " << in.size() << " (Klicks: " << presses << ")\n";
	if (total > 0) o << "Durchschnitt CPS: " << presses / (total / tps) << "\n";

	// Abstände zwischen aufeinanderfolgenden Inputs (Frame-Window-Counter)
	std::map<int, int> hist;
	std::vector<std::pair<int, int>> tightList; // (frame, gap)
	int minGap = INT_MAX;
	int simultaneous = 0;
	for (size_t i = 1; i < in.size(); i++) {
		int gap = in[i].frame - in[i - 1].frame;
		if (gap == 0) { simultaneous++; continue; }
		hist[gap]++;
		minGap = std::min(minGap, gap);
		if (gap <= tight) tightList.push_back({ in[i].frame, gap });
	}

	if (minGap != INT_MAX) {
		o << "\nKleinstes Fenster: " << minGap << " Frame(s) = " << minGap * msPerFrame << " ms\n";
	}
	o << "Gleichzeitige Inputs (Gap 0): " << simultaneous << "\n";
	o << "Enge Inputs (<= " << tight << " Frames): " << tightList.size() << "\n";

	// Off-grid: Inputs, die auf 60 fps NICHT möglich wären
	int offGrid = 0;
	if (gridStep > 1) {
		for (auto& i : in) if (i.frame % gridStep != 0) offGrid++;
		o << "Inputs nicht auf 60-fps-Raster (nur mit " << tps << " TPS möglich): " << offGrid << " / " << in.size() << "\n";
	}

	// Histogramm
	o << "\n--- Frame-Window-Counter (Abstand -> Anzahl) ---\n";
	int shown = 0;
	for (auto& [gap, count] : hist) {
		if (gap > std::max(tight * 2, 12) || shown >= 25) break;
		o << std::setw(4) << gap << " Frames (" << std::setw(6) << gap * msPerFrame << " ms): " << count << "x\n";
		shown++;
	}

	// Haltedauer
	std::map<int, int> downAt;
	std::vector<int> holds;
	for (auto& i : in) {
		int key = i.button * 2 + (i.p1 ? 1 : 0);
		if (i.down) downAt[key] = i.frame;
		else if (downAt.count(key)) { holds.push_back(i.frame - downAt[key]); downAt.erase(key); }
	}
	if (!holds.empty()) {
		int mn = *std::min_element(holds.begin(), holds.end());
		int mx = *std::max_element(holds.begin(), holds.end());
		double avg = 0; for (int h : holds) avg += h; avg /= holds.size();
		o << "\n--- Haltedauer ---\nMin: " << mn << "  Max: " << mx << "  Ø: " << avg << " Frames\n";
		int shortHolds = std::count_if(holds.begin(), holds.end(), [&](int h) { return h <= tight; });
		o << "Kurze Klicks (<= " << tight << " Frames): " << shortHolds << "\n";
	}

	// Liste der engen Stellen
	if (!tightList.empty()) {
		o << "\n--- Enge Stellen (max. 40) ---\n";
		int n = 0;
		for (auto& [frame, gap] : tightList) {
			if (n++ >= 40) { o << "... und " << tightList.size() - 40 << " weitere\n"; break; }
			o << "Frame " << frame << " (" << frame / tps << " s): Abstand " << gap
			  << " Frames = " << gap * msPerFrame << " ms\n";
		}
	}

	Macro::lastReport = o.str();

	std::ostringstream s;
	s << std::fixed << std::setprecision(1);
	s << "Frames: " << total << " (" << total / tps << " s @ " << static_cast<int>(tps) << " TPS)\n"
	  << "Inputs: " << in.size() << "\n";
	if (minGap != INT_MAX) s << "Kleinstes Fenster: " << minGap << " Fr = " << minGap * msPerFrame << " ms\n";
	s << "Enge Inputs: " << tightList.size() << "\n";
	if (gridStep > 1) s << "Nur mit " << static_cast<int>(tps) << " TPS moeglich: " << offGrid << "\n";
	Macro::lastSummary = s.str();

	// Dateien speichern
	try {
		auto dir = Mod::get()->getSaveDir();
		std::time_t t = std::time(nullptr);
		std::ostringstream name;
		name << t;
		auto reportPath = dir / ("report_" + name.str() + ".txt");
		auto csvPath = dir / ("macro_" + name.str() + ".csv");

		std::ofstream(reportPath) << Macro::lastReport;
		std::ofstream csv(csvPath);
		csv << "frame,down,button,player\n";
		for (auto& i : in) csv << i.frame << "," << (i.down ? 1 : 0) << "," << i.button << "," << (i.p1 ? 1 : 2) << "\n";

		Macro::lastPath = dir.string();
	} catch (...) {
		log::warn("Konnte Report nicht speichern");
	}
}

static void finishRecording() {
	Macro::recording = false;
	Macro::armed = false;
	analyzeMacro();
	FLAlertLayer::create(
		"Macro-Scan",
		Macro::lastSummary + "\nReport gespeichert in:\n" + Macro::lastPath,
		"OK"
	)->show();
}

// ---------------------------------------------------------------------------
// Hooks: Frame-Zähler + Input-Aufnahme
// ---------------------------------------------------------------------------
class $modify(MacroGJBGL, GJBaseGameLayer) {
	void processCommands(float dt) {
		GJBaseGameLayer::processCommands(dt);
		if (Macro::recording && PlayLayer::get()) Macro::frame++;
	}

	void handleButton(bool down, int button, bool isPlayer1) {
		if (Macro::recording && PlayLayer::get()) {
			Macro::inputs.push_back({ Macro::frame, down, button, isPlayer1 });
		}
		GJBaseGameLayer::handleButton(down, button, isPlayer1);
	}
};

class $modify(MacroPlayLayer, PlayLayer) {
	void resetLevel() {
		PlayLayer::resetLevel();
		if (Macro::armed || Macro::recording) {
			// Aufnahme immer ab Levelstart (neu beginnen bei jedem Tod/Restart)
			Macro::inputs.clear();
			Macro::frame = 0;
			Macro::recording = true;
			Macro::armed = false;
		}
	}

	void levelComplete() {
		PlayLayer::levelComplete();
		if (Macro::recording) finishRecording();
	}

	void onQuit() {
		Macro::recording = false;
		Macro::armed = false;
		PlayLayer::onQuit();
	}
};

// ---------------------------------------------------------------------------
// Pause-Menü: Buttons
// ---------------------------------------------------------------------------
class $modify(MacroPauseLayer, PauseLayer) {
	struct Fields {
		ButtonSprite* recSprite = nullptr;
	};

	static const char* recLabel() {
		if (Macro::recording) return "Stop+Scan";
		if (Macro::armed) return "Bereit...";
		return "Rec";
	}

	void customSetup() {
		PauseLayer::customSetup();

		auto winSize = CCDirector::get()->getWinSize();
		auto menu = CCMenu::create();
		menu->setID("macro-menu"_spr);
		menu->setPosition({ winSize.width - 60.f, 60.f });

		auto recSpr = ButtonSprite::create(recLabel(), 80, true, "bigFont.fnt", "GJ_button_01.png", 30.f, 0.6f);
		m_fields->recSprite = recSpr;
		auto recBtn = CCMenuItemSpriteExtra::create(recSpr, this, menu_selector(MacroPauseLayer::onRec));
		recBtn->setPosition({ 0.f, 20.f });
		menu->addChild(recBtn);

		auto scanSpr = ButtonSprite::create("Report", 80, true, "bigFont.fnt", "GJ_button_02.png", 30.f, 0.6f);
		auto scanBtn = CCMenuItemSpriteExtra::create(scanSpr, this, menu_selector(MacroPauseLayer::onScan));
		scanBtn->setPosition({ 0.f, -20.f });
		menu->addChild(scanBtn);

		this->addChild(menu);
	}

	void onRec(CCObject*) {
		if (Macro::recording) {
			finishRecording();
		} else if (Macro::armed) {
			Macro::armed = false;
		} else {
			Macro::armed = true;
			Notification::create("Macro bereit - Level neu starten!", NotificationIcon::Info)->show();
		}
		if (m_fields->recSprite) m_fields->recSprite->setString(recLabel());
	}

	void onScan(CCObject*) {
		if (Macro::lastReport.empty()) {
			Notification::create("Noch kein Macro gescannt", NotificationIcon::Warning)->show();
			return;
		}
		FLAlertLayer::create(
			"Letzter Scan",
			Macro::lastSummary + "\nDateien in:\n" + Macro::lastPath,
			"OK"
		)->show();
	}
};
